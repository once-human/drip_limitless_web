<?php
$themeName = 'Drip Social';

$themeFolder = 'wondertag';

$themeAuthor = 'Yaglewad Onkar';

$themeAuthorUrl = 'https://bit.ly/k_97';

$themeVirsion = '2.3.6';

$themeImg = $themeFolder . '/themeLogo.png';
?>